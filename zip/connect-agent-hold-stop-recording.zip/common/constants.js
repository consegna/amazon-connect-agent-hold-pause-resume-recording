const constants = {
    'STATE_CHANGE': 'STATE_CHANGE',
    'CONNECTED_ONHOLD': 'CONNECTED_ONHOLD',
    'CONNECTED': 'CONNECTED',
}

module.exports = constants
